git-repl(1) -- git read-eval-print-loop
=======================================

## SYNOPSIS

`git-repl`

## DESCRIPTION

## OPTIONS

  GIT read-eval-print-loop:

    $ git repl
     
    git> ls-files
    History.md
    Makefile
    Readme.md
    bin/git-changelog
    bin/git-count
    bin/git-delete-branch
    bin/git-delete-tag
    bin/git-ignore
    bin/git-release
 
    git> quit

## EXAMPLES

## AUTHOR

Written by Tj Holowaychuk &lt;<tj@vision-media.ca>&gt;

## REPORTING BUGS

&lt;<http://github.com/visionmedia/git-extras/issues>&gt;

## SEE ALSO

&lt;<http://github.com/visionmedia/git-extras>&gt;
