<NAME>(1) -- <short description>
================================

## SYNOPSIS

`<NAME>` [OPTIONS]

## DESCRIPTION

## OPTIONS

## EXAMPLES

## AUTHOR

Written by <AUTHOR> <EMAIL> [and <SECOND_AUTHOR> <EMAIL>]

## REPORTING BUGS

&lt;<http://github.com/visionmedia/git-extras/issues>&gt;

## SEE ALSO

&lt;<http://github.com/visionmedia/git-extras>&gt;
