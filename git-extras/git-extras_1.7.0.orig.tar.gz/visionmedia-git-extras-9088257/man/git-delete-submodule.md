git-delete-submodule(1) -- Delete submodules
============================================

## SYNOPSIS

`git-delete-submodule` &lt;path&gt;

## DESCRIPTION

## OPTIONS

  &lt;path&gt;

  The path of the submodule to delete.

## EXAMPLES

    $ git delete-submodule lib/foo

## AUTHOR

Written by Jonhnny Weslley &lt;<jw@jonhnnyweslley.net>&gt;

## REPORTING BUGS

&lt;<http://github.com/visionmedia/git-extras/issues>&gt;

## SEE ALSO

&lt;<http://github.com/visionmedia/git-extras>&gt;
